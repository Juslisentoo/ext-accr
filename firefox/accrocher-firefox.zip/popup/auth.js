/**
 * Auth — Supabase OAuth via browser extension
 * 
 * Login is delegated to the background script (which survives
 * popup closure in Firefox). The popup sends a message and
 * waits for the response.
 */

import { getConfig } from './config.js'
import { SESSION_KEY } from '../background/constants.js'

const api = globalThis.browser || globalThis.chrome

/**
 * Get stored session
 */
export async function getSession() {
  const result = await api.storage.local.get(SESSION_KEY)
  return result[SESSION_KEY] || null
}

/**
 * Save session
 */
async function saveSession(session) {
  await api.storage.local.set({ [SESSION_KEY]: session })
}

/**
 * Clear session
 */
async function clearSession() {
  await api.storage.local.remove(SESSION_KEY)
}

/**
 * Check if user is authenticated (valid token)
 */
export async function isAuthenticated() {
  const session = await getSession()
  if (!session?.access_token) return false

  // Check if token has expired
  if (session.expires_at) {
    const now = Math.floor(Date.now() / 1000)
    if (now >= session.expires_at) {
      // Try to refresh
      const refreshed = await refreshToken()
      return !!refreshed
    }
  }

  return true
}

/**
 * Login via Google OAuth — delegates to background script
 * so the auth flow survives popup closure (Firefox).
 */
export async function login() {
  // Send message to background script to handle OAuth
  const response = await api.runtime.sendMessage({ action: 'doLogin' })

  if (!response?.success) {
    throw new Error(response?.error || 'Échec de l\'authentification')
  }

  return response.session
}

/**
 * Refresh the access token using the refresh token
 */
async function refreshToken() {
  const session = await getSession()
  const config = await getConfig()

  if (!session?.refresh_token || !config.supabaseUrl || !config.supabaseKey) {
    await clearSession()
    return null
  }

  try {
    const response = await fetch(`${config.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': config.supabaseKey,
      },
      body: JSON.stringify({
        refresh_token: session.refresh_token,
      }),
    })

    if (!response.ok) {
      await clearSession()
      return null
    }

    const data = await response.json()

    const newSession = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
      token_type: 'bearer',
    }

    await saveSession(newSession)
    return newSession
  } catch (err) {
    console.error('Token refresh error:', err)
    await clearSession()
    return null
  }
}

/**
 * Logout
 */
export async function logout() {
  const session = await getSession()
  const config = await getConfig()

  // Revoke token on Supabase if possible
  if (session?.access_token && config.supabaseUrl && config.supabaseKey) {
    try {
      await fetch(`${config.supabaseUrl}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'apikey': config.supabaseKey,
        },
      })
    } catch {
      // Ignore errors on logout
    }
  }

  await clearSession()
}

/**
 * Config — Re-exports shared constants for popup modules.
 * Single source of truth lives in background/constants.js
 */

import { getConfig, CONFIG_KEY, DEFAULT_CONFIG } from '../background/constants.js'

export { getConfig }

const api = globalThis.browser || globalThis.chrome

/**
 * Save extension config to storage
 */
export async function saveConfig(config) {
  const current = await getConfig()
  const merged = { ...current, ...config }
  await api.storage.local.set({ [CONFIG_KEY]: merged })
}

/**
 * Clear config
 */
export async function clearConfig() {
  await api.storage.local.remove(CONFIG_KEY)
}

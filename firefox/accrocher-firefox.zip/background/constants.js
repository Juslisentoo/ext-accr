/**
 * Shared constants — single source of truth for config & keys.
 * Imported by both background/service-worker.js and popup/config.js
 */

const api = globalThis.browser || globalThis.chrome

export const SESSION_KEY = 'accrocher_session'
export const CONFIG_KEY = 'accrocher_config'

export const DEFAULT_CONFIG = {
  siteUrl: 'https://accrocher-psi.vercel.app',
  supabaseUrl: 'https://fkbsijraidqqpolxbyft.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZrYnNpanJhaWRxcXBvbHhieWZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MDEwOTEsImV4cCI6MjA4NjE3NzA5MX0.dryb7CuZgbMkBo6aDE4JYCgMyLRH8zBgZPCPTeOc-sE',
}

/**
 * Get the extension config from storage, merged with defaults
 */
export async function getConfig() {
  const result = await api.storage.local.get(CONFIG_KEY)
  return { ...DEFAULT_CONFIG, ...(result[CONFIG_KEY] || {}) }
}

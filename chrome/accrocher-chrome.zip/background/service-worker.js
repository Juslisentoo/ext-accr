/**
 * Accrocher — Background Service Worker
 * 
 * Handles:
 * - OAuth login via identity.launchWebAuthFlow (survives popup close)
 * - Token refresh on alarm
 * - Context menu (right-click → Share to Accrocher)
 */

import { getConfig, SESSION_KEY } from './constants.js'

const api = globalThis.browser || globalThis.chrome
const isFirefox = !!globalThis.browser

// ─── Message Handler (login from popup) ───
api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Only accept messages from this extension
  if (sender.id !== api.runtime.id) return
  if (message.action === 'doLogin') {
    handleLogin().then(
      (session) => sendResponse({ success: true, session }),
      (err) => sendResponse({ success: false, error: err.message })
    )
    return true // keep message channel open for async response
  }
})

async function handleLogin() {
  const config = await getConfig()

  const redirectUrl = api.identity.getRedirectURL()

  const authUrl = new URL(`${config.supabaseUrl}/auth/v1/authorize`)
  authUrl.searchParams.set('provider', 'google')
  authUrl.searchParams.set('redirect_to', redirectUrl)

  // launchWebAuthFlow lives in background — survives popup close
  let responseUrl
  if (isFirefox) {
    responseUrl = await api.identity.launchWebAuthFlow({
      url: authUrl.toString(),
      interactive: true,
    })
  } else {
    responseUrl = await new Promise((resolve, reject) => {
      api.identity.launchWebAuthFlow(
        { url: authUrl.toString(), interactive: true },
        (response) => {
          if (api.runtime.lastError) {
            reject(new Error(api.runtime.lastError.message))
            return
          }
          resolve(response)
        }
      )
    })
  }

  const hashPart = responseUrl.includes('#') ? responseUrl.split('#')[1] : ''
  const hashParams = new URLSearchParams(hashPart)

  const accessToken = hashParams.get('access_token')
  const refreshTokenValue = hashParams.get('refresh_token')
  const expiresIn = parseInt(hashParams.get('expires_in') || '3600')

  if (!accessToken) {
    throw new Error('Pas de token reçu')
  }

  const session = {
    access_token: accessToken,
    refresh_token: refreshTokenValue,
    expires_at: Math.floor(Date.now() / 1000) + expiresIn,
    token_type: 'bearer',
  }

  await api.storage.local.set({ [SESSION_KEY]: session })
  return session
}

// ─── Context Menu ───
api.runtime.onInstalled.addListener(() => {
  api.contextMenus.create({
    id: 'share-to-accrocher',
    title: 'Partager sur Accrocher',
    contexts: ['page', 'link'],
  })
})

// Click on context menu → open popup
api.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'share-to-accrocher') {
    const urlToShare = info.linkUrl || info.pageUrl || tab?.url
    if (urlToShare) {
      api.storage.local.set({ accrocher_pending_url: urlToShare })
      api.windows.create({
        url: api.runtime.getURL('popup/popup.html') + '?url=' + encodeURIComponent(urlToShare),
        type: 'popup',
        width: 400,
        height: 560,
      })
    }
  }
})

// ─── Token Refresh Alarm ───
api.alarms.create('refresh-token', { periodInMinutes: 45 })

api.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'refresh-token') return

  try {
    const result = await api.storage.local.get(SESSION_KEY)
    const session = result[SESSION_KEY]
    if (!session?.refresh_token) return

    const config = await getConfig()

    // Check if token expires within the next hour
    const now = Math.floor(Date.now() / 1000)
    if (session.expires_at && now < session.expires_at - 3600) {
      return // Still valid for more than an hour, skip
    }

    const response = await fetch(
      `${config.supabaseUrl}/auth/v1/token?grant_type=refresh_token`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': config.supabaseKey,
        },
        body: JSON.stringify({
          refresh_token: session.refresh_token,
        }),
      }
    )

    if (response.ok) {
      const data = await response.json()
      const newSession = {
        access_token: data.access_token,
        refresh_token: data.refresh_token,
        expires_at: Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
        token_type: 'bearer',
      }
      await api.storage.local.set({ [SESSION_KEY]: newSession })
    } else {
      console.warn('[Accrocher] Token refresh failed:', response.status)
    }
  } catch (err) {
    console.error('[Accrocher] Token refresh error:', err)
  }
})
